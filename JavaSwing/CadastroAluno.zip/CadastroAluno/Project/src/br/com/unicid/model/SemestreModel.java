package br.com.unicid.model;

public class SemestreModel {
	
	private Integer idSemestre;
	private String semestre;
	
	public Integer getIdSemestre() {
		return idSemestre;
	}
	public void setIdSemestre(Integer idSemestre) {
		this.idSemestre = idSemestre;
	}
	public String getSemestre() {
		return semestre;
	}
	public void setSemestre(String semestre) {
		this.semestre = semestre;
	}
}
